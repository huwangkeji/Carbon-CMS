<?php
/**
 * 氢CMS · 企业级服务器监控大屏 — 数据采集层
 * 分离式架构：独立 PHP 采集模块，供入口 index.php 调用。
 *
 * 兼容性：
 *   - PHP 7.4 ~ 8.5（避免使用 PHP8 专属语法，如 ?->、str_contains、match、箭头函数等）
 *   - Windows（WMIC 为主，PowerShell 回退）与 Linux / macOS（shell 命令）
 *
 * 返回结构：
 *   server  -> 服务器基础 / 资源信息（CPU/内存/Swap/负载/运行时间/网络流量）
 *   php     -> PHP 运行环境
 *   disks   -> 磁盘分区明细
 */

// ---------- 平台辅助 ----------
function hcms_is_windows() {
    return (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN');
}

// 安全执行命令行，返回去空白后的字符串；shell 不可用或失败返回空串
function hcms_exec($cmd) {
    if (!function_exists('shell_exec')) return '';
    if (ini_get('disable_functions') && stripos(ini_get('disable_functions'), 'shell_exec') !== false) return '';
    $out = @shell_exec($cmd . ' 2>' . (hcms_is_windows() ? 'NUL' : '/dev/null'));
    return ($out === null) ? '' : trim($out);
}

// 从 "KEY=value" 多行输出中提取指定 key 的值
function hcms_wmic_value($out, $key) {
    if ($out === '') return '';
    foreach (preg_split("/\r\n|\n|\r/", $out) as $line) {
        if (preg_match('/^' . preg_quote($key, '/') . '\s*=\s*(.+)$/i', trim($line), $m)) {
            return trim($m[1]);
        }
    }
    return '';
}

// ---------- 服务器信息 ----------
function hcms_collect_server() {
    $info = array();
    $info['server_name'] = php_uname('n');
    $info['os']           = php_uname('s') . ' ' . php_uname('r');
    $info['architecture'] = php_uname('m');
    $info['server_time']  = date('Y-m-d H:i:s');
    $info['server_ip']    = $_SERVER['SERVER_ADDR'] ?? $_SERVER['LOCAL_ADDR'] ?? (isset($_SERVER['SERVER_NAME']) ? gethostbyname($_SERVER['SERVER_NAME']) : 'N/A');
    $info['document_root']= $_SERVER['DOCUMENT_ROOT'] ?? '';

    $info['cpu_cores'] = 'N/A';
    $info['load_avg']  = 'N/A';
    $info['mem_total'] = 'N/A';
    $info['mem_used']  = 'N/A';
    $info['mem_free']  = 'N/A';
    $info['swap_total']= 'N/A';
    $info['swap_used'] = 'N/A';
    $info['swap_free'] = 'N/A';
    $info['uptime']    = 'N/A';
    $info['net_rx']    = 'N/A';
    $info['net_tx']    = 'N/A';

    if (!function_exists('shell_exec')) return $info;

    if (hcms_is_windows()) {
        hcms_collect_windows($info);
    } else {
        hcms_collect_unix($info);
    }

    return $info;
}

// ---------- Linux / macOS 采集 ----------
function hcms_collect_unix(&$info) {
    $cores = hcms_exec('nproc');
    if ($cores !== '') $info['cpu_cores'] = $cores;

    $load = hcms_exec('uptime');
    if ($load !== '' && preg_match('/load average: ([\d\.]+), ([\d\.]+), ([\d\.]+)/', $load, $m)) {
        $info['load_avg'] = $m[1] . ', ' . $m[2] . ', ' . $m[3];
    }

    $up = hcms_exec('cat /proc/uptime');
    if ($up !== '') {
        $parts = explode(' ', $up);
        $sec = intval(trim($parts[0]));
        $info['uptime'] = hcms_format_uptime($sec);
    }

    // 内存与 Swap
    $meminfo = @shell_exec('free -m 2>' . (hcms_is_windows() ? 'NUL' : '/dev/null'));
    if ($meminfo) {
        $lines = explode("\n", $meminfo);
        foreach ($lines as $l) {
            $cells = preg_split('/\s+/', trim($l));
            if (!empty($cells)) {
                if ($cells[0] === 'Mem:' && isset($cells[1], $cells[2], $cells[3])) {
                    $info['mem_total'] = $cells[1] . ' MB';
                    $info['mem_used']  = $cells[2] . ' MB';
                    $info['mem_free']  = $cells[3] . ' MB';
                } elseif ($cells[0] === 'Swap:' && isset($cells[1], $cells[2], $cells[3])) {
                    $info['swap_total'] = $cells[1] . ' MB';
                    $info['swap_used']  = $cells[2] . ' MB';
                    $info['swap_free']  = $cells[3] . ' MB';
                }
            }
        }
    }

    // 网络流量（排除回环 lo）
    $net = hcms_exec("grep -v 'lo:' /proc/net/dev");
    if ($net !== '') {
        $rx = 0; $tx = 0;
        foreach (preg_split("/\r\n|\n|\r/", $net) as $line) {
            if (preg_match('/:\s*(\d+)\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+(\d+)/', $line, $m)) {
                $rx += $m[1]; $tx += $m[2];
            }
        }
        $info['net_rx'] = round($rx / 1048576, 2);
        $info['net_tx'] = round($tx / 1048576, 2);
    }
}

// ---------- Windows 采集（WMIC 优先，PowerShell 回退） ----------
function hcms_collect_windows(&$info) {
    // CPU 核心数
    $cores = hcms_exec('wmic cpu get NumberOfCores /value');
    $cores = hcms_wmic_value($cores, 'NumberOfCores');
    if ($cores === '') {
        $cores = hcms_exec('powershell -NoProfile -Command "(Get-CimInstance Win32_Processor).NumberOfCores"');
    }
    if ($cores !== '') $info['cpu_cores'] = trim($cores);

    // CPU 使用率
    $cpuLoad = hcms_exec('wmic cpu get LoadPercentage /value');
    $cpuLoad = hcms_wmic_value($cpuLoad, 'LoadPercentage');
    if ($cpuLoad === '') {
        $cpuLoad = hcms_exec('powershell -NoProfile -Command "(Get-CimInstance Win32_Processor).LoadPercentage"');
    }
    if (is_numeric($cpuLoad)) {
        $info['load_avg'] = $cpuLoad . ', ' . $cpuLoad . ', ' . $cpuLoad; // Windows 无 load average，用 CPU 占用近似
    }

    // 内存（KB）
    $os = hcms_exec('wmic OS get TotalVisibleMemorySize,FreePhysicalMemory /value');
    $memTotal = hcms_wmic_value($os, 'TotalVisibleMemorySize');
    $memFree  = hcms_wmic_value($os, 'FreePhysicalMemory');
    if ($memTotal === '' || $memFree === '') {
        $os = hcms_exec('powershell -NoProfile -Command "$v=(Get-CimInstance Win32_OperatingSystem); \"$($v.TotalVisibleMemorySize) $($v.FreePhysicalMemory)\""');
        $parts = preg_split('/\s+/', trim($os));
        if (count($parts) >= 2) { $memTotal = $parts[0]; $memFree = $parts[1]; }
    }
    if (is_numeric($memTotal) && is_numeric($memFree)) {
        $memTotalMB = intval($memTotal) / 1024;
        $memFreeMB  = intval($memFree) / 1024;
        $memUsedMB  = $memTotalMB - $memFreeMB;
        $info['mem_total'] = round($memTotalMB) . ' MB';
        $info['mem_used']  = round($memUsedMB) . ' MB';
        $info['mem_free']  = round($memFreeMB) . ' MB';
    }

    // 运行时间
    $boot = hcms_exec('wmic OS get LastBootUpTime /value');
    $boot = hcms_wmic_value($boot, 'LastBootUpTime');
    if ($boot === '') {
        $boot = hcms_exec('powershell -NoProfile -Command "(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToString(\"yyyyMMddHHmmss\")"');
    }
    if (preg_match('/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/', $boot, $b)) {
        $bootTs = mktime(intval($b[4]), intval($b[5]), intval($b[6]), intval($b[2]), intval($b[3]), intval($b[1]));
        if ($bootTs > 0 && $bootTs < time()) {
            $info['uptime'] = hcms_format_uptime(time() - $bootTs);
        }
    }

    // 网络流量（累计收发字节 → MB）
    $net = hcms_exec('powershell -NoProfile -Command "$s=Get-NetAdapterStatistics; (($s|Measure-Object ReceivedBytes -Sum).Sum/1MB).ToString(\"0.00\")"');
    $netTx = hcms_exec('powershell -NoProfile -Command "$s=Get-NetAdapterStatistics; (($s|Measure-Object SentBytes -Sum).Sum/1MB).ToString(\"0.00\")"');
    if (is_numeric(trim($net)) && is_numeric(trim($netTx))) {
        $info['net_rx'] = round(floatval(trim($net)), 2);
        $info['net_tx'] = round(floatval(trim($netTx)), 2);
    }
}

// 秒数 → "X天 X小时 X分"
function hcms_format_uptime($sec) {
    $sec = intval($sec);
    if ($sec < 0) return 'N/A';
    $d = intdiv($sec, 86400);
    $h = intdiv($sec % 86400, 3600);
    $m = intdiv($sec % 3600, 60);
    return $d . '天 ' . $h . '小时 ' . $m . '分';
}

// ---------- PHP 运行环境 ----------
function hcms_collect_php() {
    return array(
        'php_version'         => phpversion(),
        'php_sapi'            => php_sapi_name(),
        'zend_version'        => zend_version(),
        'memory_limit'        => ini_get('memory_limit'),
        'max_execution_time'  => ini_get('max_execution_time'),
        'upload_max_filesize' => ini_get('upload_max_filesize'),
        'post_max_size'       => ini_get('post_max_size'),
    );
}

// ---------- 磁盘信息 ----------
function hcms_collect_disks() {
    $disks = array();

    if (hcms_is_windows()) {
        foreach (range('C', 'Z') as $drive) {
            $path = $drive . ':\\';
            $total = @disk_total_space($path);
            if ($total !== false && $total > 0) {
                $free = @disk_free_space($path);
                $used = $total - $free;
                $percent = ($total > 0) ? round(($used / $total) * 100, 1) : 0;
                $disks[] = array(
                    'name'   => $drive . '盘',
                    'total'  => round($total / (1024*1024*1024), 2),
                    'used'   => round($used / (1024*1024*1024), 2),
                    'free'   => round($free / (1024*1024*1024), 2),
                    'percent'=> $percent
                );
            }
        }
    } else {
        // Linux / macOS：优先使用 df -h
        $df = hcms_exec('df -h');
        if ($df !== '') {
            foreach (preg_split("/\r\n|\n|\r/", $df) as $line) {
                if (preg_match('/^\/dev\/\S+/', $line)) {
                    $parts = preg_split('/\s+/', $line);
                    if (count($parts) >= 6) {
                        $mount = $parts[5];
                        $total = $parts[1];
                        $used  = $parts[2];
                        $free  = $parts[3];
                        $percent = rtrim($parts[4], '%');
                        if (!preg_match('#^(/dev|/run|/sys|/proc|/tmp)#', $mount)) {
                            if (is_numeric($total)) {
                                $total = round($total / 1024, 2) . 'G';
                                $used  = round($used / 1024, 2) . 'G';
                                $free  = round($free / 1024, 2) . 'G';
                            }
                            $disks[] = array(
                                'name'   => $mount,
                                'total'  => $total,
                                'used'   => $used,
                                'free'   => $free,
                                'percent'=> (float)$percent
                            );
                        }
                    }
                }
            }
        }

        // 回退：使用 PHP 内置函数检测根目录或当前目录（macOS 无 /dev 挂载时）
        if (empty($disks) && function_exists('disk_total_space')) {
            $paths = array('/', __DIR__, $_SERVER['DOCUMENT_ROOT'] ?? '');
            foreach ($paths as $path) {
                if ($path && ($total = @disk_total_space($path))) {
                    $free = @disk_free_space($path);
                    $used = $total - $free;
                    $percent = ($total > 0) ? round(($used / $total) * 100, 1) : 0;
                    $disks[] = array(
                        'name'   => ($path == '/' ? '根目录' : basename($path)),
                        'total'  => round($total / (1024*1024*1024), 2),
                        'used'   => round($used / (1024*1024*1024), 2),
                        'free'   => round($free / (1024*1024*1024), 2),
                        'percent'=> $percent
                    );
                    break;
                }
            }
        }
    }

    if (empty($disks)) {
        $disks[] = array(
            'name'    => '无法获取磁盘信息',
            'total'   => 'N/A',
            'used'    => 'N/A',
            'free'    => 'N/A',
            'percent' => 0
        );
    }

    return $disks;
}

// ---------- 统一入口 ----------
function hcms_collect_all() {
    return array(
        'server' => hcms_collect_server(),
        'php'    => hcms_collect_php(),
        'disks'  => hcms_collect_disks(),
    );
}