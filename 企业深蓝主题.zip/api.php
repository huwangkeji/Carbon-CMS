<?php
/**
 * 氢CMS · 服务器监控上报接口 API
 * =========================================================
 * 用途：供后期统一管理系统（管理中心）远程读取本节点监控数据。
 * 远程方式：GET /api.php     ← 普通请求（完整 JSON）
 *           GET /api.php?ping=1  ← 心跳探测（轻量状态）
 *           GET /api.php?key=配置的共享密钥  ← 可选密钥鉴权
 *
 * 兼容性：PHP 7.4 ~ 8.5，Windows / Linux / macOS。
 *
 * 返回 JSON 结构：
 *   {
 *     "success": true,
 *     "api": "hcms/1.0",
 *     "id": "节点唯一ID",
 *     "node_name": "节点名称",
 *     "timestamp": 1710000000,
 *     "server": {...},
 *     "php": {...},
 *     "disks": [...],
 *     "generated_at": "2026-XX-XX XX:XX:XX"
 *   }
 */
error_reporting(0);
ob_start();

// ---------- 节点身份标识（部署时可修改，或改为写配置文件） ----------
const HCMS_NODE_ID   = 'node-heicat-001';   // 节点唯一标识
const HCMS_NODE_NAME = '氢CMS-主服务器';      // 节点显示名称
const HCMS_API_KEY   = '';                  // 为空则不校验；不为空则 ?key= 必须匹配

// 允许跨域（管理中心可能在不同域名/端口）；生产可收紧
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-API-Key');
header('Cache-Control: no-store, no-cache, must-revalidate');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ---------- 密钥鉴权（可选） ----------
if (HCMS_API_KEY !== '') {
    $got = $_GET['key'] ?? ($_SERVER['HTTP_X_API_KEY'] ?? '');
    if (!is_string($got)) $got = '';
    if (!hash_equals(HCMS_API_KEY, $got)) {
        http_response_code(401);
        die(json_encode(array(
            'success' => false,
            'error'   => 'unauthorized'
        )));
    }
}

// ---------- 心跳探测：仅返回轻量状态，避免远程频繁轮询拖累采集 ----------
if (isset($_GET['ping'])) {
    die(json_encode(array(
        'success'   => true,
        'api'       => 'hcms/1.0',
        'id'        => HCMS_NODE_ID,
        'node_name' => HCMS_NODE_NAME,
        'status'    => 'online',
        'timestamp' => time()
    )));
}

// ---------- 采集并返回完整数据 ----------
require __DIR__ . '/modules/collect.php';

$data = hcms_collect_all();
$now  = time();

// 组装上报 payload
$payload = array(
    'success'      => true,
    'api'          => 'hcms/1.0',
    'id'           => HCMS_NODE_ID,
    'node_name'    => HCMS_NODE_NAME,
    'platform'     => hcms_is_windows() ? 'Windows' : 'Unix/Linux',
    'timestamp'    => $now,
    'generated_at' => date('Y-m-d H:i:s', $now),
    'uptime_seconds' => hcms_uptime_seconds($data['server']['uptime']),
    'server'       => $data['server'],
    'php'          => $data['php'],
    'disks'        => $data['disks'],
);

echo json_encode($payload, JSON_UNESCAPED_UNICODE);
exit;

/**
 * 从 "X天 X小时 X分" 还原秒数（弱解析，失败返回 0）
 */
function hcms_uptime_seconds($uptimeStr) {
    if (!is_string($uptimeStr) || $uptimeStr === 'N/A') return 0;
    $sec = 0;
    if (preg_match('/\s*(\d+)\s*天/', $uptimeStr, $m)) $sec += intval($m[1]) * 86400;
    if (preg_match('/\s*(\d+)\s*小时/', $uptimeStr, $m)) $sec += intval($m[1]) * 3600;
    if (preg_match('/\s*(\d+)\s*分/', $uptimeStr, $m)) $sec += intval($m[1]) * 60;
    return $sec;
}