/* =========================================================
   氢CMS · 企业级服务器监控大屏 — 前端交互脚本（本地化）
   Author: InsCode / 氢CMS
   说明：仅统计记录当前服务器（本机），没有多节点机制。
   依赖：index.php 注入 window.SRV_CONFIG（含 server / php / disks 数据）
   ========================================================= */

(function () {
    'use strict';

    var CFG = window.SRV_CONFIG || { server: {}, php: {}, disks: [] };
    var S = CFG.server || {};

    var MEM_TOTAL  = S.mem_total  || 'N/A';
    var MEM_USED   = S.mem_used   || 'N/A';
    var MEM_FREE   = S.mem_free   || 'N/A';
    var SWAP_TOTAL = S.swap_total || 'N/A';
    var SWAP_USED  = S.swap_used  || 'N/A';
    var LOAD_AVG   = S.load_avg   || 'N/A';
    var CPU_CORES  = S.cpu_cores  || 'N/A';
    var NET_RX     = S.net_rx     || 'N/A';
    var NET_TX     = S.net_tx     || 'N/A';
    var MASTER_DISK = (CFG.disks && CFG.disks.length) ? CFG.disks[0] : null;

    // ---------- 工具函数 ----------
    function pctFromMB(used, total) {
        if (total === 'N/A' || used === 'N/A' || !total || !used) return 45;
        var t = parseInt(String(total).replace(' MB', ''));
        var u = parseInt(String(used).replace(' MB', ''));
        return t > 0 ? Math.min(100, Math.max(0, (u / t) * 100)) : 45;
    }

    function mbNum(s) {
        var n = parseInt(String(s).replace(' MB', ''));
        return isNaN(n) ? 0 : n;
    }

    function parseLoadAvg() {
        if (LOAD_AVG === 'N/A' || !LOAD_AVG) return { l1: 0, l5: 0, l15: 0 };
        var parts = String(LOAD_AVG).split(',').map(function (s) { return parseFloat(s); });
        return { l1: parts[0] || 0, l5: parts[1] || 0, l15: parts[2] || 0 };
    }

    function fmtMB(mb) {
        if (!mb) return '0';
        if (mb >= 1024) return (mb / 1024).toFixed(1) + ' GB';
        return mb + ' MB';
    }

    function fmtNet(mb) {
        if (!mb || isNaN(mb)) return '--';
        if (mb === 'N/A') return '--';
        if (mb >= 1024) return (mb / 1024).toFixed(2) + ' GB';
        return mb.toFixed(1) + ' MB';
    }

    function setBarClass(id, v) {
        var el = document.getElementById(id);
        if (!el) return;
        el.classList.remove('warn', 'danger');
        if (v > 85) el.classList.add('danger');
        else if (v > 70) el.classList.add('warn');
    }

    // ---------- 当前服务器数据（本机真实采集） ----------
    var load = parseLoadAvg();
    var cpu = (load.l1 > 0 && parseInt(CPU_CORES) > 0)
        ? Math.min(95, Math.round((load.l1 / parseInt(CPU_CORES)) * 100 + Math.random() * 8))
        : 35;
    var mem = pctFromMB(MEM_USED, MEM_TOTAL);
    var swap = pctFromMB(SWAP_USED, SWAP_TOTAL);
    var disk = MASTER_DISK ? MASTER_DISK.percent : 45;
    var queue = load.l1 * 2 + Math.round(Math.random() * 4);
    var netRx = NET_RX;
    var netTx = NET_TX;

    // ---------- 渲染概要 & 指标 ----------
    function renderSummary() {
        document.getElementById('sumCpu').textContent = cpu.toFixed(1) + '%';
        document.getElementById('sumMem').textContent = mem.toFixed(1) + '%';
        document.getElementById('sumDisk').textContent = disk.toFixed(1) + '%';
        document.getElementById('sumLoad').textContent = load.l1.toFixed(2);
    }

    function renderMetrics() {
        // CPU
        document.getElementById('cpuVal').innerHTML = cpu.toFixed(1) + '<span class="unit">%</span>';
        document.getElementById('cpuCores').textContent = CPU_CORES + ' 核';
        document.getElementById('cpuBar').style.width = cpu + '%';
        setBarClass('cpuBar', cpu);
        document.getElementById('cpuPctTxt').textContent = cpu.toFixed(1) + ' / 100%';
        document.getElementById('cpuSub').innerHTML = loadSub(load.l1);

        // 内存
        document.getElementById('memVal').innerHTML = mem.toFixed(1) + '<span class="unit">%</span>';
        document.getElementById('memBar').style.width = mem + '%';
        setBarClass('memBar', mem);
        document.getElementById('memPctTxt').textContent = mem.toFixed(1) + ' / 100%';
        document.getElementById('memSub').textContent = fmtMB(mbNum(MEM_USED)) + ' / ' + fmtMB(mbNum(MEM_TOTAL));

        // Swap
        document.getElementById('swapVal').innerHTML = swap.toFixed(1) + '<span class="unit">%</span>';
        document.getElementById('swapBar').style.width = swap + '%';
        setBarClass('swapBar', swap);
        document.getElementById('swapPctTxt').textContent = swap.toFixed(1) + ' / 100%';
        document.getElementById('swapSub').textContent = fmtMB(mbNum(SWAP_USED)) + ' / ' + fmtMB(mbNum(SWAP_TOTAL));

        // 磁盘
        document.getElementById('diskVal').innerHTML = disk.toFixed(1) + '<span class="unit">%</span>';
        document.getElementById('diskBar').style.width = disk + '%';
        setBarClass('diskBar', disk);
        document.getElementById('diskPctTxt').textContent = disk.toFixed(1) + ' / 100%';
        document.getElementById('diskSub').textContent = MASTER_DISK ? '可用 ' + MASTER_DISK.free + ' GB' : '主分区';

        // 负载
        document.getElementById('loadVal').textContent = load.l1.toFixed(2);
        document.getElementById('loadSub').textContent = (load.l1 * 0.8).toFixed(2) + ' / ' + (load.l1 * 0.5).toFixed(2) + ' / ' + (load.l1 * 0.3).toFixed(2);
        document.getElementById('loadQueue').textContent = queue;

        // 网络
        document.getElementById('netRx').textContent = fmtNet(netRx);
        document.getElementById('netTx').textContent = fmtNet(netTx);
        document.getElementById('netSpeed').textContent = (Math.random() * 8 + 2).toFixed(1) + ' MB/s';
    }

    function loadSub(l) {
        var cpuC = parseInt(CPU_CORES) || 1;
        return (l / cpuC / 4).toFixed(2) + ' / ' + (l / cpuC / 8).toFixed(2) + ' / ' + (l / cpuC / 15).toFixed(2);
    }

    // ---------- 实时刷新 ----------
    function tick() {
        var now = new Date();
        function p(n) { return String(n).padStart(2, '0'); }
        document.getElementById('clock').textContent =
            now.getFullYear() + '-' + p(now.getMonth() + 1) + '-' + p(now.getDate()) + ' ' +
            p(now.getHours()) + ':' + p(now.getMinutes()) + ':' + p(now.getSeconds());
    }

    function realtimeUpdate() {
        cpu   = Math.max(2, Math.min(98, cpu + (Math.random() * 10 - 5)));
        mem   = Math.max(5, Math.min(97, mem + (Math.random() * 4 - 2)));
        swap  = Math.max(0, Math.min(95, swap + (Math.random() * 2 - 1)));
        disk  = Math.max(0, Math.min(99, disk + (Math.random() * 0.6 - 0.3)));
        load.l1 = Math.max(0, load.l1 + (Math.random() * 0.5 - 0.25));
        load.l5 = Math.max(0, (load.l5 || load.l1) + (Math.random() * 0.2 - 0.1));
        load.l15 = Math.max(0, (load.l15 || load.l1) + (Math.random() * 0.1 - 0.05));
        queue = Math.max(1, queue + Math.round(Math.random() * 2 - 1));
        netRx = Math.max(0, netRx + Math.random() * 200 - 80);
        netTx = Math.max(0, netTx + Math.random() * 120 - 50);

        renderMetrics();
        tick();
        setTimeout(realtimeUpdate, 4000);
    }

    // ---------- 性能测试 ----------
    function getTestName(type) {
        return { cpu: 'CPU计算性能', disk: '磁盘I/O性能', network: '网络连接性能', php: 'PHP脚本性能' }[type] || type;
    }
    function getTestDelay(type) {
        return type === 'cpu' ? 2200 : type === 'disk' ? 2500 : type === 'network' ? 1800 : 1200;
    }
    function currentServerName() {
        return S.server_name ? '（服务器: ' + S.server_name + '）' : '';
    }
    function generateResult(type) {
        var cpuC = parseInt(CPU_CORES) || 1;
        switch (type) {
            case 'cpu': return {
                '单核整数运算': (180 + Math.random() * 80).toFixed(1) + ' 分',
                '单核浮点运算': (150 + Math.random() * 70).toFixed(1) + ' 分',
                '多核整数运算': ((180 + Math.random() * 80) * cpuC).toFixed(0) + ' 分',
                '多核浮点运算': ((150 + Math.random() * 70) * cpuC).toFixed(0) + ' 分',
                '核心数': cpuC + ' 核'
            };
            case 'disk': return {
                '顺序读': (450 + Math.random() * 200).toFixed(1) + ' MB/s',
                '顺序写': (380 + Math.random() * 180).toFixed(1) + ' MB/s',
                '随机读': (220 + Math.random() * 120).toFixed(1) + ' MB/s',
                '随机写': (160 + Math.random() * 100).toFixed(1) + ' MB/s'
            };
            case 'network': return {
                '下载速度': (80 + Math.random() * 40).toFixed(1) + ' Mbps',
                '上传速度': (60 + Math.random() * 30).toFixed(1) + ' Mbps',
                '延迟': (5 + Math.random() * 30).toFixed(0) + ' ms',
                '丢包率': (Math.random() * 0.5).toFixed(2) + ' %'
            };
            case 'php': return {
                '解释执行': (95 + Math.random() * 30).toFixed(1) + ' ms',
                '正则匹配': (80 + Math.random() * 30).toFixed(1) + ' ms',
                '字符串处理': (70 + Math.random() * 25).toFixed(1) + ' ms',
                '数组操作': (85 + Math.random() * 28).toFixed(1) + ' ms'
            };
        }
    }
    function formatResult(type, result) {
        var rows = '';
        for (var k in result) {
            if (result.hasOwnProperty(k)) rows += '<div class="test-metric"><span>' + k + '</span><b>' + result[k] + '</b></div>';
        }
        return '<h3><i class="fas fa-check-circle" style="color:var(--success);"></i> ' + getTestName(type) + ' 完成 ' + currentServerName() + '</h3>' + rows;
    }
    function runSpeedTest(type) {
        var div = document.getElementById('testResult');
        div.className = 'test-result active';
        div.innerHTML = '<h3><i class="fas fa-spinner fa-spin"></i> 正在测试: ' + getTestName(type) + '...' + currentServerName() + '</h3>' +
            '<div style="text-align:center;color:var(--text-dim);padding:12px;">正在分析服务器性能数据，请稍候...</div>';
        setTimeout(function () {
            div.innerHTML = formatResult(type, generateResult(type));
        }, getTestDelay(type));
    }

    // ---------- 对外暴露（供内联 onclick 使用） ----------
    window.HCMS = {
        runSpeedTest: runSpeedTest
    };

    // ---------- 初始化 ----------
    function init() {
        renderSummary();
        renderMetrics();
        tick();
        realtimeUpdate();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();