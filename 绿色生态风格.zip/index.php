<?php
/**
 * 氢CMS · 企业级服务器监控大屏 — 入口 / 视图控制器（分离式架构）
 *
 * 目录结构：
 *   index.php             入口：采集数据 -> 注入配置 -> 渲染 HTML 骨架
 *   modules/collect.php   数据采集层（server / php / disks）
 *   assets/css/style.css  本地样式表（无 CDN）
 *   assets/js/app.js      本地前端脚本（经 SRV_CONFIG 读取数据）
 *   assets/vendor/fontawesome/  本地字体图标库
 */
error_reporting(0);
ob_start();

require __DIR__ . '/modules/collect.php';

$HCMS_DATA = hcms_collect_all();
$S   = $HCMS_DATA['server'];
$PHP = $HCMS_DATA['php'];
$DISKS = $HCMS_DATA['disks'];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>氢CMS · 企业级服务器监控大屏</title>
    <!-- 本地化资源，无任何 CDN 依赖 -->
    <link rel="stylesheet" href="assets/vendor/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- 后端数据注入：前端 app.js 通过 window.SRV_CONFIG 读取 -->
    <script>
        window.SRV_CONFIG = <?php echo json_encode($HCMS_DATA, JSON_UNESCAPED_UNICODE); ?>;
    </script>
</head>
<body>

    <!-- 顶部大屏标题栏（居中） -->
    <header class="screen-header">
        <div class="screen-title">
            <div class="logo-badge"><i class="fas fa-leaf"></i></div>
            <div>
                <h1>氢CMS · 服务器生态监控大屏</h1>
                <div class="sub">HYDROGEN CMS · ECO SERVER MONITORING</div>
            </div>
        </div>
        <div class="screen-meta">
            <span class="meta-chip"><span class="live-dot"></span> 监控系统运行中</span>
            <span class="meta-chip"><i class="fas fa-clock"></i><span id="clock">--</span></span>
            <span class="meta-chip"><i class="fas fa-seedling"></i> 生态环保 · 低碳运维</span>
            <button class="btn-outline" onclick="location.reload()"><i class="fas fa-sync-alt"></i> 刷新数据</button>
        </div>
    </header>

    <div class="monitor-area">

            <!-- 概要数据条 -->
            <div class="summary-strip">
                <div class="summary-card">
                    <div class="icon"><i class="fas fa-microchip"></i></div>
                    <div>
                        <div class="val" id="sumCpu">--</div>
                        <div class="lbl">CPU 使用率</div>
                    </div>
                </div>
                <div class="summary-card">
                    <div class="icon"><i class="fas fa-memory"></i></div>
                    <div>
                        <div class="val" id="sumMem">--</div>
                        <div class="lbl">内存使用率</div>
                    </div>
                </div>
                <div class="summary-card">
                    <div class="icon"><i class="fas fa-hdd"></i></div>
                    <div>
                        <div class="val" id="sumDisk">--</div>
                        <div class="lbl">磁盘使用率</div>
                    </div>
                </div>
                <div class="summary-card">
                    <div class="icon"><i class="fas fa-tasks"></i></div>
                    <div>
                        <div class="val" id="sumLoad">--</div>
                        <div class="lbl">系统负载</div>
                    </div>
                </div>
            </div>

            <!-- 系统资源监控指标栅格 -->
            <div class="metric-grid">
                <!-- CPU -->
                <div class="metric-card">
                    <div class="metric-head">
                        <div class="metric-title"><i class="fas fa-microchip"></i> CPU</div>
                        <span class="metric-badge" id="cpuCores"></span>
                    </div>
                    <div class="metric-value" id="cpuVal">--<span class="unit">%</span></div>
                    <div class="metric-sub"><span>使用率</span><span id="cpuSub"></span></div>
                    <div class="metric-progress">
                        <div class="bar-label"><span>占用</span><span id="cpuPctTxt">--</span></div>
                        <div class="bar"><div class="bar-fill" id="cpuBar" style="width:0%"></div></div>
                    </div>
                </div>

                <!-- 内存 -->
                <div class="metric-card">
                    <div class="metric-head">
                        <div class="metric-title"><i class="fas fa-memory"></i> 内存</div>
                        <span class="metric-badge"><i class="fas fa-circle" style="font-size:6px;color:var(--success);"></i></span>
                    </div>
                    <div class="metric-value" id="memVal">--<span class="unit">%</span></div>
                    <div class="metric-sub"><span>已用 / 总计</span><span id="memSub"></span></div>
                    <div class="metric-progress">
                        <div class="bar-label"><span>已用</span><span id="memPctTxt">--</span></div>
                        <div class="bar"><div class="bar-fill" id="memBar" style="width:0%"></div></div>
                    </div>
                </div>

                <!-- Swap -->
                <div class="metric-card">
                    <div class="metric-head">
                        <div class="metric-title"><i class="fas fa-exchange-alt"></i> Swap</div>
                        <span class="metric-badge">交换分区</span>
                    </div>
                    <div class="metric-value" id="swapVal">--<span class="unit">%</span></div>
                    <div class="metric-sub"><span>已用 / 总计</span><span id="swapSub"></span></div>
                    <div class="metric-progress">
                        <div class="bar-label"><span>已用</span><span id="swapPctTxt">--</span></div>
                        <div class="bar"><div class="bar-fill" id="swapBar" style="width:0%"></div></div>
                    </div>
                </div>

                <!-- 磁盘 -->
                <div class="metric-card">
                    <div class="metric-head">
                        <div class="metric-title"><i class="fas fa-hdd"></i> 磁盘</div>
                        <span class="metric-badge">主分区</span>
                    </div>
                    <div class="metric-value" id="diskVal">--<span class="unit">%</span></div>
                    <div class="metric-sub"><span>主分区</span><span id="diskSub"></span></div>
                    <div class="metric-progress">
                        <div class="bar-label"><span>占用</span><span id="diskPctTxt">--</span></div>
                        <div class="bar"><div class="bar-fill" id="diskBar" style="width:0%"></div></div>
                    </div>
                </div>

                <!-- 负载 -->
                <div class="metric-card">
                    <div class="metric-head">
                        <div class="metric-title"><i class="fas fa-tasks"></i> 系统负载</div>
                        <span class="metric-badge">LOAD</span>
                    </div>
                    <div class="metric-value" id="loadVal">--</div>
                    <div class="metric-sub"><span>1min / 5min / 15min</span><span id="loadSub"></span></div>
                    <div class="net-rows">
                        <div class="net-row">
                            <div class="d"><i class="fas fa-gauge-high"></i> 运行队列</div>
                            <div class="v" id="loadQueue">--</div>
                        </div>
                    </div>
                </div>

                <!-- 网络流量 -->
                <div class="metric-card">
                    <div class="metric-head">
                        <div class="metric-title"><i class="fas fa-network-wired"></i> 网络流量</div>
                        <span class="metric-badge">NET</span>
                    </div>
                    <div class="net-rows">
                        <div class="net-row">
                            <div class="d"><i class="fas fa-arrow-down"></i> 累计接收</div>
                            <div class="v" id="netRx">--</div>
                        </div>
                        <div class="net-row">
                            <div class="d"><i class="fas fa-arrow-up"></i> 累计发送</div>
                            <div class="v" id="netTx">--</div>
                        </div>
                        <div class="net-row">
                            <div class="d"><i class="fas fa-wifi"></i> 网速</div>
                            <div class="v" id="netSpeed">--</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 概要明细 -->
            <div class="detail-row">
                <div class="panel">
                    <div class="panel-head"><div class="panel-title"><i class="fas fa-server"></i> 服务器信息</div></div>
                    <div class="kv-grid">
                        <div class="kv-item"><div class="k">主机名</div><div class="v"><?php echo htmlspecialchars($S['server_name']); ?></div></div>
                        <div class="kv-item"><div class="k">操作系统</div><div class="v"><?php echo htmlspecialchars($S['os']); ?></div></div>
                        <div class="kv-item"><div class="k">架构</div><div class="v"><?php echo htmlspecialchars($S['architecture']); ?></div></div>
                        <div class="kv-item"><div class="k">运行时间</div><div class="v"><?php echo $S['uptime']; ?></div></div>
                    </div>
                </div>

                <div class="panel">
                    <div class="panel-head"><div class="panel-title"><i class="fas fa-hdd"></i> 磁盘空间</div></div>
                    <div class="disk-list">
                        <?php if (!empty($DISKS)): foreach ($DISKS as $disk): ?>
                        <div class="disk-block">
                            <div class="disk-head">
                                <span class="disk-name"><?php echo htmlspecialchars($disk['name']); ?></span>
                                <span class="disk-perc"><?php echo $disk['percent']; ?>%</span>
                            </div>
                            <div class="bar" style="height:7px;">
                                <div class="bar-fill <?php echo ($disk['percent'] > 85) ? 'danger' : (($disk['percent'] > 70) ? 'warn' : ''); ?>" style="width: <?php echo $disk['percent']; ?>%;"></div>
                            </div>
                            <div class="disk-info">
                                <span>已用: <?php echo $disk['used']; ?> GB</span>
                                <span>剩余: <?php echo $disk['free']; ?> GB</span>
                                <span>总计: <?php echo $disk['total']; ?> GB</span>
                            </div>
                        </div>
                        <?php endforeach; else: ?>
                            <p style="text-align:center;color:var(--text-dim);padding:16px;">无法获取磁盘信息</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- 运行环境 -->
            <div class="detail-row">
                <div class="panel">
                    <div class="panel-head"><div class="panel-title"><i class="fab fa-php"></i> PHP 环境</div></div>
                    <div class="kv-grid">
                        <div class="kv-item"><div class="k">PHP 版本</div><div class="v"><?php echo $PHP['php_version']; ?></div></div>
                        <div class="kv-item"><div class="k">运行方式</div><div class="v"><?php echo $PHP['php_sapi']; ?></div></div>
                        <div class="kv-item"><div class="k">Zend 引擎</div><div class="v"><?php echo $PHP['zend_version']; ?></div></div>
                        <div class="kv-item"><div class="k">内存限制</div><div class="v"><?php echo $PHP['memory_limit']; ?></div></div>
                        <div class="kv-item"><div class="k">执行时间</div><div class="v"><?php echo $PHP['max_execution_time']; ?> 秒</div></div>
                        <div class="kv-item"><div class="k">上传限制</div><div class="v"><?php echo $PHP['upload_max_filesize']; ?></div></div>
                    </div>
                </div>

                <div class="panel">
                    <div class="panel-head"><div class="panel-title"><i class="fas fa-tachometer-alt"></i> 性能测试</div></div>
                    <div class="perf-grid">
                        <div class="perf-cell" onclick="window.HCMS.runSpeedTest('cpu')"><i class="fas fa-microchip"></i><div class="t">CPU 测试</div><div class="d">计算性能</div></div>
                        <div class="perf-cell" onclick="window.HCMS.runSpeedTest('disk')"><i class="fas fa-hdd"></i><div class="t">磁盘 I/O</div><div class="d">读写速度</div></div>
                        <div class="perf-cell" onclick="window.HCMS.runSpeedTest('network')"><i class="fas fa-wifi"></i><div class="t">网络测试</div><div class="d">连接速度</div></div>
                        <div class="perf-cell" onclick="window.HCMS.runSpeedTest('php')"><i class="fab fa-php"></i><div class="t">PHP 性能</div><div class="d">脚本执行</div></div>
                    </div>
                    <div class="test-result" id="testResult"></div>
                </div>
            </div>

        </div>

    <footer class="footer">
        氢CMS网络服务监控插件 · 企业监控大屏 | 页面生成时间: <?php echo round(microtime(true) - $_SERVER['REQUEST_TIME_FLOAT'], 4); ?> 秒
    </footer>

    <!-- 本地脚本 -->
    <script src="assets/js/app.js"></script>
</body>
</html>